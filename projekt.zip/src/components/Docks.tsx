import { useEffect, useRef, useState } from "react";
import { api, errText, Stats } from "../lib/api";
import { useStore } from "../store";
import { useTwitchLink } from "../twitchLink";
import { fmtTime, useEngine } from "../engine";
import { DockId } from "../lib/layout";

export function Unavailable({ phase, what }: { phase: number; what: string }) {
  return (
    <div className="unavail">
      <span className="badge">Phase {phase}</span>
      <p>{what}</p>
      <small>Noch nicht verfügbar.</small>
    </div>
  );
}

function ScenesDock() {
  const { s, set } = useStore();
  const scenes: string[] = safeList(s.scenes);
  const active = s.active_scene ?? scenes[0];
  const [adding, setAdding] = useState("");
  const [editing, setEditing] = useState<{ i: number; v: string } | null>(null);
  const save = (list: string[], act?: string) => { void set("scenes", JSON.stringify(list)); if (act) void set("active_scene", act); };

  return (
    <div className="dock-body">
      <ul className="list">
        {scenes.length === 0 && <li className="empty">Noch keine Szene. Lege unten deine erste an.</li>}
        {scenes.map((n, i) => (
          <li key={n + i} className={n === active ? "sel" : ""} onClick={() => set("active_scene", n)}>
            {editing?.i === i ? (
              <input autoFocus value={editing.v} onChange={(e) => setEditing({ i, v: e.target.value })}
                onBlur={() => setEditing(null)}
                onKeyDown={(e) => {
                  if (e.key === "Escape") setEditing(null);
                  if (e.key === "Enter") {
                    const v = editing.v.trim();
                    if (v && (v === n || !scenes.includes(v))) save(scenes.map((x, j) => (j === i ? v : x)), n === active ? v : undefined);
                    setEditing(null);
                  }
                }} />
            ) : (
              <>
                <span onDoubleClick={() => setEditing({ i, v: n })} title="Doppelklick zum Umbenennen">{n}</span>
                <button className="mini" title="Szene löschen" onClick={(e) => { e.stopPropagation(); const l = scenes.filter((_, j) => j !== i); save(l, l[0] ?? ""); }}>✕</button>
              </>
            )}
          </li>
        ))}
      </ul>
      <form className="row" onSubmit={(e) => { e.preventDefault(); const v = adding.trim(); if (v && !scenes.includes(v)) { save([...scenes, v], scenes.length === 0 ? v : undefined); setAdding(""); } }}>
        <input placeholder="Neue Szene …" value={adding} onChange={(e) => setAdding(e.target.value)} />
        <button className="btn small" type="submit">Hinzufügen</button>
      </form>
    </div>
  );
}

export function safeList(raw?: string): string[] {
  try { const v = JSON.parse(raw ?? "[]"); return Array.isArray(v) ? v.filter((x) => typeof x === "string") : []; } catch { return []; }
}

const gb = (b: number) => (b / 1024 ** 3).toFixed(1) + " GB";
const mb = (b: number) => Math.round(b / 1024 ** 2) + " MB";

function PerfDock() {
  const [st, setSt] = useState<Stats | null>(null);
  useEffect(() => {
    let alive = true;
    const tick = () => api.stats().then((v) => alive && setSt(v)).catch(() => {});
    tick();
    const t = window.setInterval(tick, 2000);
    return () => { alive = false; clearInterval(t); };
  }, []);
  if (!st) return <div className="dock-body"><p className="empty">Messe …</p></div>;
  const Row = ({ k, v, pct }: { k: string; v: string; pct?: number }) => (
    <div className="stat"><span>{k}</span><b>{v}</b>{pct !== undefined && <i style={{ width: `${Math.min(100, pct)}%` }} />}</div>
  );
  return (
    <div className="dock-body stats">
      <Row k="CPU gesamt" v={`${st.cpu.toFixed(0)} %`} pct={st.cpu} />
      <Row k="RAM gesamt" v={`${gb(st.mem_used)} / ${gb(st.mem_total)}`} pct={(st.mem_used / st.mem_total) * 100} />
      <Row k="IBIS IV (CPU)" v={`${st.proc_cpu.toFixed(1)} %`} />
      <Row k="IBIS IV (RAM, Hauptprozess)" v={mb(st.proc_mem)} />
      <small className="muted">FPS, Dropped Frames, GPU, Encoder und Bitrate folgen mit der Streaming-Engine (Phase 3 und 9).</small>
    </div>
  );
}

function ControlsDock({ openView }: { openView: (v: string) => void }) {
  const { active, busy, start, stop } = useEngine();
  const { account } = useTwitchLink();
  return (
    <div className="dock-body controls">
      <button className={`btn ${active.stream ? "" : "primary"}`} disabled={busy || (!active.stream && !account)}
        title={!account ? "Verbinde zuerst Twitch (Einstellungen → Twitch)" : ""}
        onClick={() => (active.stream ? stop("stream") : start("stream"))}>
        {active.stream ? "Stream beenden" : "Stream starten"}
      </button>
      <button className="btn" disabled={busy} onClick={() => (active.record ? stop("record") : start("record"))}>
        {active.record ? "Aufnahme beenden" : "Aufnahme starten"}
      </button>
      <button className="btn" onClick={() => openView("settings")}>Einstellungen</button>
      <button className="btn" onClick={() => openView("repair")}>Reparatur &amp; Sicherung</button>
    </div>
  );
}

function StatusDock() {
  const { account } = useTwitchLink();
  const { active, stats } = useEngine();
  const st = stats.stream; const rc = stats.record;
  return (
    <div className="dock-body">
      <div className="stat"><span>Stream</span><b className={active.stream ? "live" : ""}>{active.stream ? "LIVE" : "Offline"}</b></div>
      {st && <>
        <div className="stat"><span>Laufzeit</span><b>{fmtTime(st.seconds)}</b></div>
        <div className="stat"><span>FPS</span><b>{st.fps.toFixed(1)}</b></div>
        <div className="stat"><span>Bitrate</span><b>{Math.round(st.bitrate)} kbps</b></div>
        <div className="stat"><span>Verworfene Bilder</span><b>{st.dropped}</b></div>
      </>}
      <div className="stat"><span>Aufnahme</span><b className={active.record ? "live" : ""}>{active.record ? (rc ? fmtTime(rc.seconds) : "startet …") : "aus"}</b></div>
      <div className="stat"><span>Twitch</span><b>{account ? `verbunden (${account.display_name})` : "nicht verbunden"}</b></div>
    </div>
  );
}

function LinkNotice({ openView }: { openView: (v: string) => void }) {
  const { account, status } = useTwitchLink();
  if (!account) return <div className="unavail"><p>Twitch ist nicht verbunden.</p><button className="btn small" onClick={() => openView("settings")}>Einstellungen öffnen</button></div>;
  if (status.state === "scopes") return <div className="unavail"><p>Neue Berechtigungen nötig. Trenne Twitch in den Einstellungen und verbinde es neu.</p><button className="btn small" onClick={() => openView("settings")}>Einstellungen öffnen</button></div>;
  return null;
}

function ChatDock({ openView }: { openView: (v: string) => void }) {
  const { account, status, chat } = useTwitchLink();
  const { toast } = useStore();
  const [text, setText] = useState("");
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => { end.current?.scrollIntoView({ block: "end" }); }, [chat.length]);
  const notice = LinkNotice({ openView });
  if (notice) return notice;
  const send = async () => {
    const m = text.trim();
    if (!m || !account) return;
    try { await api.chatSend(account.id, m); setText(""); } catch (e) { toast(errText(e), "error"); }
  };
  return (
    <div className="dock-body chat">
      <small className="muted">{status.state === "connected" ? "Verbunden" : status.state === "connecting" ? "Verbinde …" : status.message ?? ""}</small>
      <div className="chatlog">
        {chat.length === 0 && <p className="muted">Noch keine Nachrichten.</p>}
        {chat.map((m, i) => (
          <p key={m.id + i}><b style={{ color: m.color || undefined }}>{m.user}</b>{m.badges.includes("broadcaster") ? " 🎙" : m.badges.includes("moderator") ? " 🛡" : ""}: {m.text}</p>
        ))}
        <div ref={end} />
      </div>
      <form className="row" onSubmit={(e) => { e.preventDefault(); void send(); }}>
        <input value={text} maxLength={500} placeholder="Nachricht senden …" onChange={(e) => setText(e.target.value)} />
        <button className="btn small primary" type="submit">Senden</button>
      </form>
    </div>
  );
}

const KIND: Record<string, string> = { follow: "Follower", sub: "Abo", resub: "Resub", gift: "Geschenk-Abos", bits: "Bits", raid: "Raid" };
function EventsDock({ openView }: { openView: (v: string) => void }) {
  const { events } = useTwitchLink();
  const notice = LinkNotice({ openView });
  if (notice) return notice;
  return (
    <div className="dock-body">
      {events.length === 0 && <p className="muted">Noch keine Ereignisse in dieser Sitzung.</p>}
      <ul className="list events">
        {events.map((e, i) => <li key={i}><span><b>{e.user}</b> {e.detail}<small> {KIND[e.kind] ?? e.kind} · {e.ts}</small></span></li>)}
      </ul>
    </div>
  );
}

export function DockContent({ id, openView }: { id: DockId; openView: (v: string) => void }) {
  switch (id) {
    case "scenes": return <ScenesDock />;
    case "sources": return <Unavailable phase={4} what="Quellen wie Game Capture, Kamera und Browser benötigen die Streaming-Engine." />;
    case "mixer": return <Unavailable phase={4} what="Der Audio-Mixer mit Filtern folgt zusammen mit der Engine." />;
    case "status": return <StatusDock />;
    case "chat": return <ChatDock openView={openView} />;
    case "events": return <EventsDock openView={openView} />;
    case "controls": return <ControlsDock openView={openView} />;
    case "perf": return <PerfDock />;
  }
}
