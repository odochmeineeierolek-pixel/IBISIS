import { useCallback, useEffect, useRef, useState } from "react";
import { openUrl } from "@tauri-apps/plugin-opener";
import { api, Category, DeviceStart, errText, TwitchAccount, TwitchChannel } from "../lib/api";
import { useStore } from "../store";
import { useTwitchLink } from "../twitchLink";

export function TwitchPanel({ compact = false }: { compact?: boolean }) {
  const { toast } = useStore();
  const link = useTwitchLink();
  const [clientId, setClientId] = useState("");
  const [connected, setConnected] = useState(false);
  const [account, setAccount] = useState<TwitchAccount | null>(null);
  const [device, setDevice] = useState<DeviceStart | null>(null);
  const [error, setError] = useState("");
  const alive = useRef(true);

  const loadAccount = useCallback(async () => {
    try { setAccount(await api.twitchAccount()); setError(""); }
    catch (e) { setError(errText(e)); setConnected(await api.twitchConnected()); }
  }, []);

  useEffect(() => {
    alive.current = true;
    (async () => {
      setClientId((await api.stateGet("twitch_client_id")) ?? "");
      const c = await api.twitchConnected();
      setConnected(c);
      if (c) await loadAccount();
    })().catch((e) => setError(errText(e)));
    return () => { alive.current = false; };
  }, [loadAccount]);

  const connect = async () => {
    setError("");
    const id = clientId.trim();
    if (!/^[a-z0-9]{20,40}$/i.test(id)) { setError("Die Client-ID sieht ungültig aus. Sie besteht aus etwa 30 Buchstaben und Zahlen."); return; }
    try {
      await api.stateSet("twitch_client_id", id);
      const d = await api.twitchLoginStart();
      setDevice(d);
      void openUrl(d.verification_uri).catch(() => {});
      const deadline = Date.now() + d.expires_in * 1000;
      let wait = d.interval * 1000;
      while (alive.current && Date.now() < deadline) {
        await new Promise((r) => setTimeout(r, wait));
        if (!alive.current) return;
        const r = await api.twitchLoginPoll(d.device_code);
        if (r.status === "ok") { setDevice(null); setConnected(true); await loadAccount(); void link.refresh(); toast("Mit Twitch verbunden."); return; }
        if (r.status === "expired") break;
        if (r.message === "slow_down") wait += 5000;
      }
      setDevice(null);
      setError("Die Anmeldung ist abgelaufen oder wurde nicht bestätigt. Starte sie erneut.");
    } catch (e) { setDevice(null); setError(errText(e)); }
  };

  const logout = async () => {
    try { await api.twitchLogout(); setConnected(false); setAccount(null); void link.refresh(); toast("Twitch getrennt."); }
    catch (e) { setError(errText(e)); }
  };

  return (
    <div>
      {!connected && !device && (
        <>
          <p>Verbinde dein Twitch-Konto. Die Anmeldung läuft über die offizielle Twitch-Seite in deinem Browser. IBIS IV sieht dein Passwort nie.</p>
          <details className="muted">
            <summary>Wo bekomme ich die Client-ID?</summary>
            <ol>
              <li>Öffne <b>dev.twitch.tv/console</b> und melde dich an (Zwei-Faktor muss aktiv sein).</li>
              <li>Klicke auf <b>Anwendung registrieren</b>. Name: z. B. „IBIS IV von DeinName“.</li>
              <li>OAuth-Weiterleitungs-URL: <b>http://localhost</b>. Kategorie: <b>Application Integration</b>. Client-Typ: <b>Öffentlich</b>.</li>
              <li>Öffne die Anwendung über <b>Verwalten</b> und kopiere die <b>Client-ID</b> hierher.</li>
            </ol>
          </details>
          <label className="field">Client-ID
            <input value={clientId} onChange={(e) => setClientId(e.target.value)} placeholder="z. B. a1b2c3d4e5f6…" spellCheck={false} /></label>
          <button className="btn primary" onClick={connect}>Mit Twitch verbinden</button>
        </>
      )}
      {device && (
        <div>
          <p>Der Browser wurde geöffnet. Bestätige dort die Anmeldung. Falls Twitch nach einem Code fragt:</p>
          <p className="usercode">{device.user_code}</p>
          <button className="btn small" onClick={() => void openUrl(device.verification_uri)}>Seite erneut öffnen</button>
          <p className="muted">Warte auf Bestätigung …</p>
        </div>
      )}
      {connected && account && (
        <div className="account">
          {account.profile_image_url && <img src={account.profile_image_url} alt="" width={48} height={48} />}
          <div><b>{account.display_name}</b><small>{account.login}{account.broadcaster_type ? ` · ${account.broadcaster_type}` : ""}</small></div>
          <button className="btn small" onClick={logout}>Verbindung trennen</button>
        </div>
      )}
      {connected && !account && !error && <p className="muted">Lade Konto …</p>}
      {error && <p className="err">{error}</p>}
      {connected && link.status.state === "scopes" && <p className="err">IBIS IV braucht neue Berechtigungen (Chat und Ereignisse). Klicke auf „Verbindung trennen“ und verbinde Twitch danach neu.</p>}
      {connected && link.status.state === "error" && <p className="err">{link.status.message}</p>}
      {connected && link.status.warnings && link.status.warnings.length > 0 && <ul className="err">{link.status.warnings.map((w) => <li key={w}>{w}</li>)}</ul>}
      {connected && account && !compact && <ChannelEditor user={account} />}
    </div>
  );
}

function ChannelEditor({ user }: { user: TwitchAccount }) {
  const { toast } = useStore();
  const [ch, setCh] = useState<TwitchChannel | null>(null);
  const [title, setTitle] = useState("");
  const [tags, setTags] = useState("");
  const [cat, setCat] = useState<Category | null>(null);
  const [q, setQ] = useState("");
  const [results, setResults] = useState<Category[]>([]);
  const [err, setErr] = useState("");

  const load = useCallback(async (resetForm: boolean) => {
    try {
      const c = await api.twitchChannel(user.id);
      setCh(c);
      if (resetForm) { setTitle(c.title); setTags((c.tags ?? []).join(", ")); setCat(c.game_id ? { id: c.game_id, name: c.game_name } : null); }
      setErr("");
    } catch (e) { setErr(errText(e)); }
  }, [user.id]);

  useEffect(() => { void load(true); const t = window.setInterval(() => void load(false), 30000); return () => clearInterval(t); }, [load]);

  const search = async () => { try { setResults(await api.twitchCategories(q)); } catch (e) { setErr(errText(e)); } };
  const save = async () => {
    try {
      const list = tags.split(/[,\s]+/).map((t) => t.trim()).filter(Boolean);
      await api.twitchUpdate(user.id, title, cat?.id ?? "", list);
      toast("Kanal-Infos gespeichert."); await load(true);
    } catch (e) { setErr(errText(e)); }
  };

  return (
    <>
      <h3>Live-Status</h3>
      {ch && (ch.live
        ? <p className="okmsg">Live · {ch.viewers} Zuschauer</p>
        : <p className="muted">Offline</p>)}
      <h3>Stream-Infos</h3>
      <label className="field">Titel ({title.length}/140)<input value={title} maxLength={140} onChange={(e) => setTitle(e.target.value)} /></label>
      <label className="field">Kategorie: <b>{cat?.name ?? "keine"}</b>
        <div className="row"><input value={q} placeholder="Spiel oder Kategorie suchen …" onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && search()} />
          <button className="btn small" onClick={search}>Suchen</button></div></label>
      {results.length > 0 && <ul className="list">{results.map((r) => <li key={r.id} onClick={() => { setCat(r); setResults([]); }}>{r.name}</li>)}</ul>}
      <label className="field">Tags (mit Komma getrennt, höchstens 10, ohne Leerzeichen im Tag)<input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="Deutsch, Gaming" /></label>
      <button className="btn primary" onClick={save}>Speichern</button>
      <p className="muted">Twitch bietet für Kanäle keine frei bearbeitbare Beschreibung über die Schnittstelle an. Titel, Kategorie und Tags sind die änderbaren Felder.</p>
      {err && <p className="err">{err}</p>}
    </>
  );
}
