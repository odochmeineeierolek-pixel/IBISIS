import { createContext, ReactNode, useCallback, useContext, useEffect, useState } from "react";
import { listen, UnlistenFn } from "@tauri-apps/api/event";
import { api, ChatMsg, errText, LinkStatus, TEvent, TwitchAccount } from "./lib/api";

interface Ctx {
  account: TwitchAccount | null;
  status: LinkStatus;
  chat: ChatMsg[];
  events: TEvent[];
  refresh: () => Promise<void>;
}
const C = createContext<Ctx>({ account: null, status: { state: "off" }, chat: [], events: [], refresh: async () => {} });
export const useTwitchLink = () => useContext(C);

/** Hält Twitch-Konto, Chat- und Ereignis-Verlauf, damit sie beim Verschieben der Docks nicht verloren gehen. */
export function TwitchLinkProvider({ children }: { children: ReactNode }) {
  const [account, setAccount] = useState<TwitchAccount | null>(null);
  const [status, setStatus] = useState<LinkStatus>({ state: "off" });
  const [chat, setChat] = useState<ChatMsg[]>([]);
  const [events, setEvents] = useState<TEvent[]>([]);

  const refresh = useCallback(async () => {
    try {
      if (!(await api.twitchConnected())) {
        await api.chatStop().catch(() => {});
        setAccount(null); setStatus({ state: "off" });
        return;
      }
      const a = await api.twitchAccount();
      setAccount(a);
      if (await api.twitchScopesOk()) await api.chatStart(a.id);
      else setStatus({ state: "scopes" });
    } catch (e) {
      setStatus({ state: "error", message: errText(e) });
    }
  }, []);

  useEffect(() => {
    let dead = false;
    const un: UnlistenFn[] = [];
    (async () => {
      const subs = [
        await listen<LinkStatus>("twitch-status", (e) => setStatus(e.payload)),
        await listen<ChatMsg>("twitch-chat", (e) => setChat((c) => [...c.slice(-199), e.payload])),
        await listen<TEvent>("twitch-event", (e) => setEvents((v) => [e.payload, ...v].slice(0, 100))),
      ];
      if (dead) subs.forEach((f) => f()); else un.push(...subs);
    })();
    void refresh();
    return () => { dead = true; un.forEach((f) => f()); };
  }, [refresh]);

  return <C.Provider value={{ account, status, chat, events, refresh }}>{children}</C.Provider>;
}
