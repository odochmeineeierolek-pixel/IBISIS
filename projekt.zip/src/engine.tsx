import { createContext, ReactNode, useCallback, useContext, useEffect, useState } from "react";
import { listen, UnlistenFn } from "@tauri-apps/api/event";
import { api, EngineStats, errText } from "./lib/api";
import { useStore } from "./store";

type Kind = "record" | "stream";
interface Ctx {
  active: Record<Kind, boolean>;
  stats: Partial<Record<Kind, EngineStats>>;
  busy: boolean;
  start: (k: Kind) => Promise<void>;
  stop: (k: Kind) => Promise<void>;
}
const C = createContext<Ctx>({ active: { record: false, stream: false }, stats: {}, busy: false, start: async () => {}, stop: async () => {} });
export const useEngine = () => useContext(C);

export const fmtTime = (sec: number) => {
  const t = Math.max(0, Math.floor(sec));
  return [Math.floor(t / 3600), Math.floor(t / 60) % 60, t % 60].map((x) => String(x).padStart(2, "0")).join(":");
};

export function EngineProvider({ children }: { children: ReactNode }) {
  const { toast } = useStore();
  const [active, setActive] = useState<Record<Kind, boolean>>({ record: false, stream: false });
  const [stats, setStats] = useState<Partial<Record<Kind, EngineStats>>>({});
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let dead = false;
    const un: UnlistenFn[] = [];
    (async () => {
      const subs = [
        await listen<EngineStats>("engine-stats", (e) => {
          setStats((s) => ({ ...s, [e.payload.kind]: e.payload }));
          setActive((a) => ({ ...a, [e.payload.kind]: true }));
        }),
        await listen<{ kind: Kind; ok: boolean; message: string }>("engine-exit", (e) => {
          setActive((a) => ({ ...a, [e.payload.kind]: false }));
          setStats((s) => ({ ...s, [e.payload.kind]: undefined }));
          if (!e.payload.ok) toast(e.payload.message || "Die Engine wurde beendet.", "error");
        }),
      ];
      if (dead) subs.forEach((f) => f()); else un.push(...subs);
    })();
    api.engineStatus().then(setActive).catch(() => {});
    return () => { dead = true; un.forEach((f) => f()); };
  }, [toast]);

  const start = useCallback(async (k: Kind) => {
    setBusy(true);
    try { await api.engineStart(k); setActive((a) => ({ ...a, [k]: true })); }
    catch (e) { toast(errText(e), "error"); }
    finally { setBusy(false); }
  }, [toast]);
  const stop = useCallback(async (k: Kind) => {
    setBusy(true);
    try { await api.engineStop(k); }
    catch (e) { toast(errText(e), "error"); }
    finally { setBusy(false); }
  }, [toast]);

  return <C.Provider value={{ active, stats, busy, start, stop }}>{children}</C.Provider>;
}
