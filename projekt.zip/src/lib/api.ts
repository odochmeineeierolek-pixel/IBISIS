import { invoke } from "@tauri-apps/api/core";

export interface Profile { id: number; name: string; active: boolean }
export interface Check { id: string; title: string; status: "ok" | "warn" | "error" | "na"; detail: string; fixable: boolean }
export interface BackupInfo { name: string; size: number; created: string }
export interface Stats { cpu: number; mem_used: number; mem_total: number; proc_cpu: number; proc_mem: number }
export interface Hw { cpu: string; cores: number; ram: number; gpus: string[]; os: string }
export interface NetEntry { host: string; ok: boolean; ms: number }

export interface TwitchAccount { id: string; login: string; display_name: string; profile_image_url: string; broadcaster_type: string }
export interface DeviceStart { device_code: string; user_code: string; verification_uri: string; expires_in: number; interval: number }
export interface PollResult { status: "pending" | "ok" | "expired"; message: string }
export interface TwitchChannel { title: string; game_id: string; game_name: string; tags: string[]; live: boolean; viewers: number; started_at: string }
export interface Category { id: string; name: string }

export interface ChatMsg { id: string; user: string; color: string; text: string; badges: string[]; ts: string }
export interface TEvent { kind: string; user: string; detail: string; ts: string }
export interface LinkStatus { state: "off" | "connecting" | "connected" | "error" | "scopes"; message?: string; warnings?: string[] }

export interface EncInfo { id: "nvenc" | "amf" | "qsv" | "x264"; label: string; works: boolean }
export interface Caps { version: string; encoders: EncInfo[]; capture: "ddagrab" | "gdigrab" }
export interface EngineStats { kind: "record" | "stream"; fps: number; bitrate: number; frames: number; dropped: number; seconds: number; speed: number }

export const api = {
  engineDetect: () => invoke<Caps>("engine_detect"),
  audioDevices: () => invoke<string[]>("engine_audio_devices"),
  engineStart: (kind: "record" | "stream") => invoke<void>("engine_start", { kind }),
  engineStop: (kind: "record" | "stream") => invoke<void>("engine_stop", { kind }),
  engineStatus: () => invoke<{ record: boolean; stream: boolean }>("engine_status"),
  twitchScopesOk: () => invoke<boolean>("twitch_scopes_ok"),
  chatStart: (userId: string) => invoke<void>("chat_start", { userId }),
  chatStop: () => invoke<void>("chat_stop"),
  chatSend: (userId: string, message: string) => invoke<void>("chat_send", { userId, message }),
  twitchConnected: () => invoke<boolean>("twitch_connected"),
  twitchLoginStart: () => invoke<DeviceStart>("twitch_login_start"),
  twitchLoginPoll: (deviceCode: string) => invoke<PollResult>("twitch_login_poll", { deviceCode }),
  twitchAccount: () => invoke<TwitchAccount>("twitch_account"),
  twitchChannel: (userId: string) => invoke<TwitchChannel>("twitch_channel", { userId }),
  twitchUpdate: (userId: string, title: string, gameId: string, tags: string[]) => invoke<void>("twitch_update", { userId, title, gameId, tags }),
  twitchCategories: (query: string) => invoke<Category[]>("twitch_categories", { query }),
  twitchLogout: () => invoke<void>("twitch_logout"),
  stateGet: (key: string) => invoke<string | null>("state_get", { key }),
  stateSet: (key: string, value: string) => invoke<void>("state_set", { key, value }),
  settingsAll: () => invoke<Record<string, string>>("settings_all"),
  settingSet: (key: string, value: string) => invoke<void>("setting_set", { key, value }),
  profiles: () => invoke<Profile[]>("profiles_list"),
  profileCreate: (name: string) => invoke<number>("profile_create", { name }),
  profileSwitch: (id: number) => invoke<void>("profile_switch", { id }),
  profileDelete: (id: number) => invoke<void>("profile_delete", { id }),
  logRead: (maxLines = 500) => invoke<string>("log_read", { maxLines }),
  logWrite: (level: "INFO" | "WARN" | "ERROR", msg: string) => invoke<void>("log_write", { level, msg }),
  dataDir: () => invoke<string>("data_dir"),
  repairCheck: () => invoke<Check[]>("repair_check"),
  repairFix: (id: string) => invoke<string>("repair_fix", { id }),
  backupCreate: () => invoke<BackupInfo>("backup_create"),
  backups: () => invoke<BackupInfo[]>("backups_list"),
  backupRestore: (name: string) => invoke<void>("backup_restore", { name }),
  backupDelete: (name: string) => invoke<void>("backup_delete", { name }),
  stats: () => invoke<Stats>("system_stats"),
  hardware: () => invoke<Hw>("hardware_detect"),
  net: () => invoke<NetEntry[]>("net_check"),
};

export function errText(e: unknown): string {
  return typeof e === "string" ? e : e instanceof Error ? e.message : "Unbekannter Fehler";
}
