# Lizenzhinweis

IBIS IV wird unter **GPL-2.0-or-later** veröffentlicht, weil die geplante Streaming-Engine
libobs (GPL-2.0) und x264 (GPL) einbindet. Der vollständige Quellcode muss mit jeder
Veröffentlichung mitgeliefert werden. Vor der Veröffentlichung den Volltext der GPL als
`LICENSE` ablegen (https://www.gnu.org/licenses/old-licenses/gpl-2.0.txt).

- Name und Logo von OBS Studio dürfen nicht verwendet werden (IBIS IV hat ein eigenes Logo).
- FFmpeg nur als LGPL-Build und dynamisch gelinkt einbinden.
- Tauri, React, rusqlite, sysinfo: MIT/Apache-2.0.

## FFmpeg im Installer
Der Installer enthält eine unveränderte GPL-Build von FFmpeg (BtbN/FFmpeg-Builds). Quellcode und Lizenztexte:
https://github.com/BtbN/FFmpeg-Builds und https://ffmpeg.org. Vor einer öffentlichen Verbreitung die genaue Version
und den Quelltext-Link in die Dokumentation aufnehmen.
