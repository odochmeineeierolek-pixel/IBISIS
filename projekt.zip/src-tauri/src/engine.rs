//! Streaming-Engine (Phase 3a) auf Basis des mitgelieferten FFmpeg.
//! Erfasst einen Monitor (+ optional ein Mikrofon), kodiert per NVENC/AMF/QSV/x264
//! und schreibt in eine Datei (Aufnahme) oder per RTMPS zu Twitch (Stream).
//! Statistiken kommen direkt aus FFmpeg (`-progress`), nichts davon ist simuliert.

use crate::{db::Db, logger, twitch};
use serde::Serialize;
use serde_json::{json, Value};
use std::{
    collections::HashMap,
    io::{BufRead, BufReader, Write},
    path::PathBuf,
    process::{Child, ChildStdin, Command, Stdio},
    sync::{Arc, Mutex},
    time::Duration,
};
use tauri::{AppHandle, Emitter, Manager, State};
#[cfg(windows)]
use std::os::windows::process::CommandExt;

pub struct Job {
    pid: u32,
    child: Arc<Mutex<Child>>,
    stdin: Option<ChildStdin>,
}
#[derive(Default)]
pub struct Engine {
    rec: Mutex<Option<Job>>,
    stream: Mutex<Option<Job>>,
}

fn slot<'a>(e: &'a Engine, kind: &str) -> &'a Mutex<Option<Job>> {
    if kind == "stream" { &e.stream } else { &e.rec }
}

pub(crate) fn ffmpeg_path() -> Result<PathBuf, String> {
    let exe = std::env::current_exe().map_err(|e| e.to_string())?;
    let dir = exe.parent().ok_or_else(|| "Programmordner nicht gefunden.".to_string())?;
    for name in ["ffmpeg.exe", "ffmpeg-x86_64-pc-windows-msvc.exe"] {
        let p = dir.join(name);
        if p.exists() {
            return Ok(p);
        }
    }
    Err("FFmpeg wurde nicht gefunden. Installiere IBIS IV neu.".into())
}

fn cmd(path: &PathBuf) -> Command {
    let mut c = Command::new(path);
    #[cfg(windows)]
    c.creation_flags(0x0800_0000); // CREATE_NO_WINDOW: nie ein Konsolenfenster
    c.stdin(Stdio::null());
    c
}

// ---------- Fähigkeiten prüfen ----------

#[derive(Serialize, Clone)]
pub struct EncInfo { id: &'static str, label: &'static str, works: bool }
#[derive(Serialize)]
pub struct Caps { version: String, encoders: Vec<EncInfo>, capture: &'static str }

/// Testet jeden Encoder mit einem echten Mini-Encode und die Bildschirmaufnahme-Methode.
#[tauri::command]
pub async fn engine_detect() -> Result<Caps, String> {
    tauri::async_runtime::spawn_blocking(|| -> Result<Caps, String> {
        let path = ffmpeg_path()?;
        let ver = cmd(&path).arg("-version").output().map_err(|e| format!("FFmpeg lässt sich nicht starten: {e}"))?;
        let version = String::from_utf8_lossy(&ver.stdout).lines().next().unwrap_or("").to_string();
        let mut encoders = vec![];
        for (id, codec, label) in [
            ("nvenc", "h264_nvenc", "NVIDIA NVENC"),
            ("amf", "h264_amf", "AMD AMF"),
            ("qsv", "h264_qsv", "Intel Quick Sync"),
            ("x264", "libx264", "x264 (Software)"),
        ] {
            let works = cmd(&path)
                .args(["-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "color=c=black:s=1280x720:r=30",
                       "-frames:v", "15", "-c:v", codec, "-f", "null", "-"])
                .output().map(|o| o.status.success()).unwrap_or(false);
            encoders.push(EncInfo { id, label, works });
        }
        let dd = cmd(&path)
            .args(["-hide_banner", "-loglevel", "error", "-filter_complex", "ddagrab=framerate=30,hwdownload,format=bgra",
                   "-frames:v", "5", "-f", "null", "-"])
            .output().map(|o| o.status.success()).unwrap_or(false);
        logger::write("INFO", &format!("Engine-Prüfung: {version}; Encoder: {:?}", encoders.iter().map(|e| (e.id, e.works)).collect::<Vec<_>>()));
        Ok(Caps { version, encoders, capture: if dd { "ddagrab" } else { "gdigrab" } })
    })
    .await
    .map_err(|e| e.to_string())?
}

#[tauri::command]
pub async fn engine_audio_devices() -> Result<Vec<String>, String> {
    tauri::async_runtime::spawn_blocking(|| -> Result<Vec<String>, String> {
        let path = ffmpeg_path()?;
        let o = cmd(&path)
            .args(["-hide_banner", "-list_devices", "true", "-f", "dshow", "-i", "dummy"])
            .output().map_err(|e| e.to_string())?;
        let text = String::from_utf8_lossy(&o.stderr).to_string();
        let mut v: Vec<String> = vec![];
        for l in text.lines() {
            if let (Some(a), Some(b)) = (l.find('"'), l.rfind("\" (audio)")) {
                if a < b {
                    let n = l[a + 1..b].to_string();
                    if !v.contains(&n) { v.push(n); }
                }
            }
        }
        Ok(v)
    })
    .await
    .map_err(|e| e.to_string())?
}

// ---------- Start / Stop ----------

pub struct Params {
    pub encoder: String, pub width: u32, pub height: u32, pub fps: u32, pub bitrate: u32,
    pub abitrate: u32, pub monitor: u32, pub mic: String, pub capture: String,
}

fn s(v: &[&str]) -> Vec<String> { v.iter().map(|x| x.to_string()).collect() }

pub fn build_args(p: &Params, output: &str, mp4: bool) -> Vec<String> {
    let mut a = s(&["-hide_banner", "-nostats", "-loglevel", "warning", "-progress", "pipe:1", "-y"]);
    let pix = if p.encoder == "x264" { "yuv420p" } else { "nv12" };
    let gdi = p.capture == "gdigrab";
    if gdi {
        a.extend(s(&["-f", "gdigrab", "-framerate", &p.fps.to_string(), "-i", "desktop"]));
    }
    let aidx = if gdi { 1 } else { 0 };
    if p.mic.is_empty() {
        a.extend(s(&["-re", "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo"]));
    } else {
        a.extend(s(&["-thread_queue_size", "1024", "-f", "dshow", "-i", &format!("audio={}", p.mic)]));
    }
    let filter = if gdi {
        format!("[0:v]scale={}:{}:flags=bicubic,format={}[v]", p.width, p.height, pix)
    } else {
        format!("ddagrab=output_idx={}:framerate={},hwdownload,format=bgra,scale={}:{}:flags=bicubic,format={}[v]",
                p.monitor, p.fps, p.width, p.height, pix)
    };
    a.extend(s(&["-filter_complex", &filter, "-map", "[v]", "-map", &format!("{aidx}:a"), "-fps_mode", "cfr"]));
    let b = format!("{}k", p.bitrate);
    let buf = format!("{}k", p.bitrate * 2);
    let g = (p.fps * 2).to_string();
    match p.encoder.as_str() {
        "nvenc" => a.extend(s(&["-c:v", "h264_nvenc", "-preset", "p4", "-tune", "ll", "-rc", "cbr", "-b:v", &b, "-maxrate", &b, "-bufsize", &buf, "-g", &g, "-bf", "2"])),
        "amf" => a.extend(s(&["-c:v", "h264_amf", "-usage", "lowlatency", "-rc", "cbr", "-b:v", &b, "-maxrate", &b, "-bufsize", &buf, "-g", &g])),
        "qsv" => a.extend(s(&["-c:v", "h264_qsv", "-preset", "veryfast", "-b:v", &b, "-maxrate", &b, "-bufsize", &buf, "-g", &g])),
        _ => a.extend(s(&["-c:v", "libx264", "-preset", "veryfast", "-b:v", &b, "-maxrate", &b, "-bufsize", &buf, "-g", &g])),
    }
    a.extend(s(&["-c:a", "aac", "-b:a", &format!("{}k", p.abitrate), "-ar", "48000", "-ac", "2", "-af", "aresample=async=1:first_pts=0"]));
    if output.starts_with("rtmp") {
        a.extend(s(&["-f", "flv", output]));
    } else {
        if mp4 { a.extend(s(&["-movflags", "+frag_keyframe+empty_moov"])); }
        a.push(output.to_string());
    }
    a
}

fn num(m: &HashMap<String, String>, v: &Value, k: &str, d: u32) -> u32 {
    let _ = m;
    v[k].as_u64().map(|x| x as u32).filter(|x| *x > 0).unwrap_or(d)
}

#[tauri::command]
pub async fn engine_start(app: AppHandle, db: State<'_, Db>, eng: State<'_, Engine>, kind: String) -> Result<(), String> {
    if kind != "stream" && kind != "record" {
        return Err("Unbekannter Modus.".into());
    }
    let running = slot(&eng, &kind).lock().unwrap_or_else(|e| e.into_inner()).is_some();
    if running {
        return Err("Läuft bereits.".into());
    }
    let m = db.settings_all()?;
    let video: Value = serde_json::from_str(m.get("video").map(|x| x.as_str()).unwrap_or("{}")).unwrap_or(json!({}));
    let caps: Value = serde_json::from_str(m.get("engine_caps").map(|x| x.as_str()).unwrap_or("{}")).unwrap_or(json!({}));
    let p = Params {
        encoder: m.get("encoder_pref").cloned().unwrap_or_else(|| "x264".into()),
        width: num(&m, &video, "width", 1920), height: num(&m, &video, "height", 1080),
        fps: num(&m, &video, "fps", 30), bitrate: num(&m, &video, "bitrate", 4500),
        abitrate: 160,
        monitor: m.get("monitor").and_then(|x| x.parse().ok()).unwrap_or(0),
        mic: m.get("mic_name").cloned().unwrap_or_default(),
        capture: caps["capture"].as_str().unwrap_or("ddagrab").to_string(),
    };
    let (output, mp4) = if kind == "stream" {
        if p.width > 1920 || p.height > 1080 {
            return Err("Twitch nimmt keine Auflösung über 1080p an. Wähle in den Einstellungen 1080p oder weniger, oder nimm lokal auf.".into());
        }
        if p.fps > 60 { return Err("Twitch unterstützt höchstens 60 FPS. Wähle 60 oder weniger, oder nimm lokal auf.".into()); }
        if p.bitrate > 8500 { return Err("Die Bitrate liegt über dem Twitch-Limit von etwa 8500 kbps.".into()); }
        let key = twitch::stream_key(&db).await?;
        (format!("rtmps://live.twitch.tv:443/app/{key}"), false)
    } else {
        let dir = match m.get("record_path").filter(|x| !x.is_empty()) {
            Some(d) => PathBuf::from(d),
            None => app.path().video_dir().map_err(|e| e.to_string())?.join("IBIS IV"),
        };
        std::fs::create_dir_all(&dir).map_err(|e| format!("Der Aufnahmeordner ist nicht beschreibbar: {e}"))?;
        let mp4 = m.get("record_format").map(|x| x == "mp4").unwrap_or(false);
        let name = format!("IBIS-{}.{}", chrono::Local::now().format("%Y%m%d-%H%M%S"), if mp4 { "mp4" } else { "mkv" });
        (dir.join(name).to_string_lossy().to_string(), mp4)
    };
    logger::write("INFO", &format!("Engine startet ({kind}): {} {}x{}@{} {}kbps, Erfassung {}", p.encoder, p.width, p.height, p.fps, p.bitrate, p.capture));
    let job = spawn_job(&app, &kind, build_args(&p, &output, mp4))?;
    *slot(&eng, &kind).lock().unwrap_or_else(|e| e.into_inner()) = Some(job);
    Ok(())
}

fn spawn_job(app: &AppHandle, kind: &str, args: Vec<String>) -> Result<Job, String> {
    let path = ffmpeg_path()?;
    let mut c = cmd(&path);
    c.args(&args).stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::piped());
    let mut child = c.spawn().map_err(|e| format!("FFmpeg konnte nicht gestartet werden: {e}"))?;
    let stdin = child.stdin.take();
    let stdout = child.stdout.take();
    let stderr = child.stderr.take();
    let pid = child.id();
    let child = Arc::new(Mutex::new(child));
    let tail: Arc<Mutex<Vec<String>>> = Arc::new(Mutex::new(vec![]));

    if let Some(se) = stderr {
        let tail = tail.clone();
        std::thread::spawn(move || {
            for line in BufReader::new(se).lines().map_while(Result::ok) {
                let mut t = tail.lock().unwrap_or_else(|e| e.into_inner());
                t.push(line);
                if t.len() > 30 { t.remove(0); }
            }
        });
    }
    let (app2, kind2, child2) = (app.clone(), kind.to_string(), child.clone());
    std::thread::spawn(move || {
        let mut cur: HashMap<String, String> = HashMap::new();
        if let Some(so) = stdout {
            for line in BufReader::new(so).lines().map_while(Result::ok) {
                if let Some((k, v)) = line.split_once('=') {
                    cur.insert(k.trim().to_string(), v.trim().to_string());
                    if k.trim() == "progress" {
                        let f = |k: &str| cur.get(k).and_then(|x| x.trim_end_matches(|c: char| !c.is_ascii_digit()).parse::<f64>().ok()).unwrap_or(0.0);
                        let _ = app2.emit("engine-stats", json!({
                            "kind": kind2, "fps": f("fps"), "bitrate": f("bitrate"), "frames": f("frame"),
                            "dropped": f("drop_frames"), "seconds": f("out_time_us") / 1_000_000.0, "speed": f("speed"),
                        }));
                        cur.clear();
                    }
                }
            }
        }
        let status = child2.lock().ok().and_then(|mut c| c.wait().ok());
        let ok = status.map(|s| s.success()).unwrap_or(false);
        std::thread::sleep(Duration::from_millis(200));
        let msg = if ok { String::new() } else {
            let t = tail.lock().unwrap_or_else(|e| e.into_inner());
            let last: Vec<&str> = t.iter().rev().take(3).map(|x| x.as_str()).collect();
            let mut l = last; l.reverse();
            logger::write("ERROR", &format!("FFmpeg ({kind2}) beendet: {}", l.join(" | ").replace("rtmps://live.twitch.tv:443/app/", "rtmps://…/")));
            friendly(&l.join(" "))
        };
        let eng = app2.state::<Engine>();
        {
            let mut g = slot(&eng, &kind2).lock().unwrap_or_else(|e| e.into_inner());
            if g.as_ref().map(|j| j.pid) == Some(pid) { *g = None; }
        }
        let _ = app2.emit("engine-exit", json!({ "kind": kind2, "ok": ok, "message": msg }));
    });
    Ok(Job { pid, child, stdin })
}

fn friendly(t: &str) -> String {
    let l = t.to_lowercase();
    if l.contains("nvenc") && (l.contains("not found") || l.contains("cannot load") || l.contains("no capable")) {
        "Die NVIDIA-Grafikkarte kann diesen Encoder nicht verwenden. Wähle in den Einstellungen einen anderen Encoder (x264 geht immer).".into()
    } else if l.contains("amf") && (l.contains("failed") || l.contains("not found")) {
        "Der AMD-Encoder startet nicht. Wähle in den Einstellungen einen anderen Encoder.".into()
    } else if l.contains("connection") || l.contains("rtmp") || l.contains("server returned") {
        "Die Verbindung zu Twitch ist fehlgeschlagen. Prüfe Internet und Twitch-Verbindung.".into()
    } else if l.contains("dshow") || l.contains("audio=") {
        "Das gewählte Mikrofon lässt sich nicht öffnen. Wähle es in den Einstellungen neu aus.".into()
    } else {
        format!("Die Engine wurde unerwartet beendet: {}", t.chars().take(220).collect::<String>())
    }
}

#[tauri::command]
pub async fn engine_stop(eng: State<'_, Engine>, kind: String) -> Result<(), String> {
    let job = slot(&eng, &kind).lock().unwrap_or_else(|e| e.into_inner()).take();
    if let Some(mut j) = job {
        if let Some(mut si) = j.stdin.take() {
            let _ = si.write_all(b"q\n"); // sauberes Beenden: Datei wird korrekt abgeschlossen
            let _ = si.flush();
        }
        tauri::async_runtime::spawn_blocking(move || {
            for _ in 0..60 {
                if let Ok(mut c) = j.child.lock() {
                    if let Ok(Some(_)) = c.try_wait() { return; }
                }
                std::thread::sleep(Duration::from_millis(100));
            }
            if let Ok(mut c) = j.child.lock() { let _ = c.kill(); }
        })
        .await
        .map_err(|e| e.to_string())?;
    }
    Ok(())
}

#[tauri::command]
pub fn engine_status(eng: State<Engine>) -> Value {
    let r = |k: &str| slot(&eng, k).lock().unwrap_or_else(|e| e.into_inner()).is_some();
    json!({ "record": r("record"), "stream": r("stream") })
}

#[cfg(test)]
mod tests {
    use super::*;
    fn p(enc: &str, cap: &str, mic: &str) -> Params {
        Params { encoder: enc.into(), width: 1920, height: 1080, fps: 60, bitrate: 6000, abitrate: 160, monitor: 0, mic: mic.into(), capture: cap.into() }
    }
    #[test]
    fn nvenc_ddagrab_stream() {
        let a = build_args(&p("nvenc", "ddagrab", ""), "rtmps://x/app/key", false);
        assert!(a.contains(&"h264_nvenc".to_string()));
        assert!(a.iter().any(|x| x.starts_with("ddagrab=output_idx=0:framerate=60")));
        assert!(a.contains(&"0:a".to_string()));
        assert_eq!(a.last().unwrap(), "rtmps://x/app/key");
        assert!(a.contains(&"flv".to_string()));
    }
    #[test]
    fn x264_gdigrab_mic_record() {
        let a = build_args(&p("x264", "gdigrab", "Mikrofon (Test)"), "C:\\v\\a.mkv", false);
        assert!(a.contains(&"libx264".to_string()));
        assert!(a.contains(&"audio=Mikrofon (Test)".to_string()));
        assert!(a.contains(&"1:a".to_string()));
        assert!(a.iter().any(|x| x.ends_with("format=yuv420p[v]")));
    }
    #[test]
    fn mp4_gets_fragmented_flags() {
        assert!(build_args(&p("x264", "ddagrab", ""), "a.mp4", true).contains(&"+frag_keyframe+empty_moov".to_string()));
    }
}
