//! Twitch EventSub per WebSocket: Chat-Nachrichten und Kanal-Ereignisse.
//! Die Ereignisse werden als Tauri-Events an die Oberfläche gesendet:
//! `twitch-status`, `twitch-chat`, `twitch-event`.

use crate::{db::Db, logger, twitch::authed};
use futures_util::{SinkExt, StreamExt};
use reqwest::Method;
use serde_json::{json, Value};
use std::{sync::Mutex, time::Duration};
use tauri::{AppHandle, Emitter, Manager, State};
use tokio_tungstenite::{connect_async, tungstenite::Message};

pub struct Hub(pub Mutex<Option<tauri::async_runtime::JoinHandle<()>>>);

const WS_URL: &str = "wss://eventsub.wss.twitch.tv/ws";

fn now() -> String {
    chrono::Local::now().format("%H:%M:%S").to_string()
}
fn friendly(e: &str) -> String {
    if e.contains("403") || e.contains("401") {
        "Berechtigung fehlt. Trenne Twitch in den Einstellungen und verbinde es neu.".to_string()
    } else {
        e.to_string()
    }
}
fn txt(v: &Value, k: &str) -> String {
    v[k].as_str().unwrap_or_default().to_string()
}

#[tauri::command]
pub fn chat_start(app: AppHandle, hub: State<Hub>, user_id: String) {
    let mut g = hub.0.lock().unwrap_or_else(|e| e.into_inner());
    if let Some(h) = g.take() {
        h.abort();
    }
    *g = Some(tauri::async_runtime::spawn(run(app, user_id)));
}

#[tauri::command]
pub fn chat_stop(app: AppHandle, hub: State<Hub>) {
    let mut g = hub.0.lock().unwrap_or_else(|e| e.into_inner());
    if let Some(h) = g.take() {
        h.abort();
    }
    let _ = app.emit("twitch-status", json!({ "state": "off" }));
}

#[tauri::command]
pub async fn chat_send(db: State<'_, Db>, user_id: String, message: String) -> Result<(), String> {
    let m = message.trim();
    if m.is_empty() || m.chars().count() > 500 {
        return Err("Die Nachricht muss 1 bis 500 Zeichen lang sein.".into());
    }
    let body = json!({ "broadcaster_id": user_id, "sender_id": user_id, "message": m });
    let v = authed(&db, Method::POST, "/chat/messages", &[], Some(body)).await.map_err(|e| friendly(&e))?;
    if v["data"][0]["is_sent"].as_bool() == Some(false) {
        let why = v["data"][0]["drop_reason"]["message"].as_str().unwrap_or("unbekannter Grund");
        return Err(format!("Twitch hat die Nachricht nicht gesendet: {why}"));
    }
    Ok(())
}

async fn run(app: AppHandle, user_id: String) {
    let mut url = WS_URL.to_string();
    let mut subscribe = true;
    let mut backoff = 2u64;
    loop {
        let _ = app.emit("twitch-status", json!({ "state": "connecting" }));
        match session(&app, &user_id, &url, subscribe).await {
            Ok(Some(next)) => {
                // Twitch bittet um Umzug auf einen anderen Server; Abos bleiben erhalten.
                url = next;
                subscribe = false;
                continue;
            }
            Ok(None) => {}
            Err(e) => {
                logger::write("WARN", &format!("EventSub: {e}"));
                let _ = app.emit("twitch-status", json!({ "state": "error", "message": e }));
            }
        }
        url = WS_URL.to_string();
        subscribe = true;
        tokio::time::sleep(Duration::from_secs(backoff)).await;
        backoff = (backoff * 2).min(30);
    }
}

async fn session(app: &AppHandle, user_id: &str, url: &str, subscribe: bool) -> Result<Option<String>, String> {
    let (mut ws, _) = connect_async(url)
        .await
        .map_err(|e| format!("Verbindung zu den Twitch-Ereignissen fehlgeschlagen: {e}"))?;
    let mut keepalive = Duration::from_secs(40);
    loop {
        let msg = match tokio::time::timeout(keepalive, ws.next()).await {
            Err(_) => return Err("Die Verbindung zu Twitch ist eingeschlafen. Verbinde neu …".into()),
            Ok(None) => return Err("Die Verbindung zu Twitch wurde beendet. Verbinde neu …".into()),
            Ok(Some(Err(e))) => return Err(format!("Verbindungsfehler: {e}")),
            Ok(Some(Ok(m))) => m,
        };
        match msg {
            Message::Text(t) => {
                let v: Value = match serde_json::from_str(&t) {
                    Ok(v) => v,
                    Err(_) => continue,
                };
                match v["metadata"]["message_type"].as_str().unwrap_or_default() {
                    "session_welcome" => {
                        let sess = &v["payload"]["session"];
                        keepalive = Duration::from_secs(sess["keepalive_timeout_seconds"].as_u64().unwrap_or(10) + 15);
                        let mut warnings: Vec<String> = vec![];
                        if subscribe {
                            warnings = subscribe_all(app, user_id, &txt(sess, "id")).await;
                        }
                        let _ = app.emit("twitch-status", json!({ "state": "connected", "warnings": warnings }));
                    }
                    "session_reconnect" => {
                        return Ok(Some(txt(&v["payload"]["session"], "reconnect_url")));
                    }
                    "revocation" => {
                        let _ = app.emit("twitch-status", json!({ "state": "connected", "warnings": ["Twitch hat ein Abonnement widerrufen. Verbinde Twitch neu."] }));
                    }
                    "notification" => handle(app, &v["payload"]),
                    _ => {}
                }
            }
            Message::Ping(d) => {
                let _ = ws.send(Message::Pong(d)).await;
            }
            Message::Close(_) => return Err("Die Verbindung zu Twitch wurde geschlossen. Verbinde neu …".into()),
            _ => {}
        }
    }
}

async fn subscribe_all(app: &AppHandle, uid: &str, session_id: &str) -> Vec<String> {
    let db = app.state::<Db>();
    let subs = vec![
        ("channel.chat.message", "1", json!({ "broadcaster_user_id": uid, "user_id": uid })),
        ("channel.follow", "2", json!({ "broadcaster_user_id": uid, "moderator_user_id": uid })),
        ("channel.subscribe", "1", json!({ "broadcaster_user_id": uid })),
        ("channel.subscription.message", "1", json!({ "broadcaster_user_id": uid })),
        ("channel.subscription.gift", "1", json!({ "broadcaster_user_id": uid })),
        ("channel.cheer", "1", json!({ "broadcaster_user_id": uid })),
        ("channel.raid", "1", json!({ "to_broadcaster_user_id": uid })),
    ];
    let mut warnings = vec![];
    for (ty, ver, cond) in subs {
        let body = json!({ "type": ty, "version": ver, "condition": cond,
            "transport": { "method": "websocket", "session_id": session_id } });
        if let Err(e) = authed(&db, Method::POST, "/eventsub/subscriptions", &[], Some(body)).await {
            warnings.push(format!("{ty}: {}", friendly(&e)));
        }
    }
    warnings
}

fn handle(app: &AppHandle, payload: &Value) {
    let ty = payload["subscription"]["type"].as_str().unwrap_or_default();
    let e = &payload["event"];
    let ev = |kind: &str, user: String, detail: String| {
        let _ = app.emit("twitch-event", json!({ "kind": kind, "user": user, "detail": detail, "ts": now() }));
    };
    match ty {
        "channel.chat.message" => {
            let badges: Vec<String> = e["badges"].as_array().map(|a| a.iter().map(|b| txt(b, "set_id")).collect()).unwrap_or_default();
            let _ = app.emit("twitch-chat", json!({
                "id": txt(e, "message_id"), "user": txt(e, "chatter_user_name"), "color": txt(e, "color"),
                "text": e["message"]["text"].as_str().unwrap_or_default(), "badges": badges, "ts": now(),
            }));
        }
        "channel.follow" => ev("follow", txt(e, "user_name"), "folgt dir jetzt".into()),
        "channel.subscribe" => {
            let gift = e["is_gift"].as_bool().unwrap_or(false);
            ev("sub", txt(e, "user_name"), if gift { "hat ein Geschenk-Abo erhalten".into() } else { "hat abonniert".into() })
        }
        "channel.subscription.message" => ev(
            "resub",
            txt(e, "user_name"),
            format!("{} Monate abonniert. {}", e["cumulative_months"].as_u64().unwrap_or(0), e["message"]["text"].as_str().unwrap_or_default()),
        ),
        "channel.subscription.gift" => {
            let who = if e["is_anonymous"].as_bool().unwrap_or(false) { "Anonym".to_string() } else { txt(e, "user_name") };
            ev("gift", who, format!("verschenkt {} Abo(s)", e["total"].as_u64().unwrap_or(1)))
        }
        "channel.cheer" => {
            let who = if e["is_anonymous"].as_bool().unwrap_or(false) { "Anonym".to_string() } else { txt(e, "user_name") };
            ev("bits", who, format!("{} Bits. {}", e["bits"].as_u64().unwrap_or(0), e["message"].as_str().unwrap_or_default()))
        }
        "channel.raid" => ev("raid", txt(e, "from_broadcaster_user_name"), format!("Raid mit {} Zuschauern", e["viewers"].as_u64().unwrap_or(0))),
        _ => {}
    }
}
