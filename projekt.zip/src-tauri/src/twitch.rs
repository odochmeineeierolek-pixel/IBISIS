//! Twitch-Anbindung (Phase 5, Teil 1): Anmeldung per Device Code Flow (kein Client-Secret),
//! Tokens im Windows-Anmeldeinformationsspeicher, Kontoinfo, Kanal-Infos und Live-Status.

use crate::{db::Db, logger};
use reqwest::Method;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::time::Duration;
use tauri::State;

pub(crate) const SCOPES: &str = "channel:manage:broadcast user:read:chat user:write:chat moderator:read:followers channel:read:subscriptions bits:read channel:read:stream_key";
const SERVICE: &str = "IBIS IV";
const TOKEN_URL: &str = "https://id.twitch.tv/oauth2/token";
const HELIX: &str = "https://api.twitch.tv/helix";

#[derive(Serialize, Deserialize, Clone)]
struct Tokens {
    access: String,
    refresh: String,
}

fn entry() -> Result<keyring::Entry, String> {
    keyring::Entry::new(SERVICE, "twitch").map_err(|e| e.to_string())
}
fn load() -> Option<Tokens> {
    entry().ok()?.get_password().ok().and_then(|s| serde_json::from_str(&s).ok())
}
fn save(t: &Tokens) -> Result<(), String> {
    let json = serde_json::to_string(t).map_err(|e| e.to_string())?;
    entry()?
        .set_password(&json)
        .map_err(|e| format!("Die Zugangsdaten konnten nicht sicher gespeichert werden: {e}"))
}
fn forget() {
    if let Ok(e) = entry() {
        let _ = e.delete_credential();
    }
}

fn http() -> reqwest::Client {
    reqwest::Client::builder()
        .timeout(Duration::from_secs(15))
        .user_agent("IBIS-IV/0.1")
        .build()
        .unwrap_or_default()
}
fn net(e: reqwest::Error) -> String {
    format!("Keine Verbindung zu Twitch. Prüfe deine Internetverbindung. ({e})")
}
async fn api_err(r: reqwest::Response) -> String {
    let st = r.status();
    let body = r.text().await.unwrap_or_default();
    let msg = serde_json::from_str::<Value>(&body)
        .ok()
        .and_then(|v| v["message"].as_str().map(|s| s.to_string()))
        .unwrap_or(body);
    if msg.to_lowercase().contains("invalid client") {
        return "Die Client-ID ist ungültig. Prüfe sie in deiner Twitch-Anwendung (dev.twitch.tv).".into();
    }
    format!("Twitch meldet Fehler {}: {}", st.as_u16(), msg)
}
fn s(v: &Value, k: &str) -> String {
    v[k].as_str().unwrap_or_default().to_string()
}
fn client_id(db: &Db) -> Result<String, String> {
    let id = db.state_get("twitch_client_id")?.unwrap_or_default();
    if id.trim().is_empty() {
        return Err("Es ist keine Twitch-Client-ID eingetragen.".into());
    }
    Ok(id.trim().to_string())
}

async fn refresh(cid: &str, t: &Tokens) -> Result<Tokens, String> {
    let r = http()
        .post(TOKEN_URL)
        .form(&[("client_id", cid), ("grant_type", "refresh_token"), ("refresh_token", t.refresh.as_str())])
        .send()
        .await
        .map_err(net)?;
    if !r.status().is_success() {
        forget();
        return Err("Die Twitch-Anmeldung ist abgelaufen. Bitte verbinde dich neu.".into());
    }
    let v: Value = r.json().await.map_err(net)?;
    let n = Tokens {
        access: s(&v, "access_token"),
        refresh: v["refresh_token"].as_str().unwrap_or(&t.refresh).to_string(),
    };
    save(&n)?;
    Ok(n)
}

/// Anfrage mit Token; bei 401 wird einmal automatisch erneuert.
pub(crate) async fn authed(db: &Db, method: Method, path: &str, query: &[(&str, &str)], body: Option<Value>) -> Result<Value, String> {
    let cid = client_id(db)?;
    let mut t = load().ok_or_else(|| "Du bist nicht mit Twitch verbunden.".to_string())?;
    for attempt in 0..2 {
        let mut rb = http()
            .request(method.clone(), format!("{HELIX}{path}"))
            .query(query)
            .bearer_auth(&t.access)
            .header("Client-Id", &cid);
        if let Some(b) = &body {
            rb = rb.json(b);
        }
        let r = rb.send().await.map_err(net)?;
        if r.status().as_u16() == 401 && attempt == 0 {
            t = refresh(&cid, &t).await?;
            continue;
        }
        if r.status().as_u16() == 204 {
            return Ok(json!({}));
        }
        if !r.status().is_success() {
            return Err(api_err(r).await);
        }
        return Ok(r.json().await.unwrap_or(json!({})));
    }
    Err("Die Twitch-Anmeldung ist abgelaufen. Bitte verbinde dich neu.".into())
}

#[tauri::command]
pub fn twitch_connected() -> bool {
    load().is_some()
}

#[derive(Serialize)]
pub struct DeviceStart {
    device_code: String,
    user_code: String,
    verification_uri: String,
    expires_in: u64,
    interval: u64,
}

#[tauri::command]
pub async fn twitch_login_start(db: State<'_, Db>) -> Result<DeviceStart, String> {
    let cid = client_id(&db)?;
    let r = http()
        .post("https://id.twitch.tv/oauth2/device")
        .form(&[("client_id", cid.as_str()), ("scopes", SCOPES)])
        .send()
        .await
        .map_err(net)?;
    if !r.status().is_success() {
        return Err(api_err(r).await);
    }
    let v: Value = r.json().await.map_err(net)?;
    logger::write("INFO", "Twitch-Anmeldung gestartet");
    Ok(DeviceStart {
        device_code: s(&v, "device_code"),
        user_code: s(&v, "user_code"),
        verification_uri: s(&v, "verification_uri"),
        expires_in: v["expires_in"].as_u64().unwrap_or(600),
        interval: v["interval"].as_u64().unwrap_or(5).max(3),
    })
}

#[derive(Serialize)]
pub struct PollResult {
    status: &'static str,
    message: String,
}

#[tauri::command]
pub async fn twitch_login_poll(db: State<'_, Db>, device_code: String) -> Result<PollResult, String> {
    let cid = client_id(&db)?;
    let r = http()
        .post(TOKEN_URL)
        .form(&[
            ("client_id", cid.as_str()),
            ("scopes", SCOPES),
            ("device_code", device_code.as_str()),
            ("grant_type", "urn:ietf:params:oauth:grant-type:device_code"),
        ])
        .send()
        .await
        .map_err(net)?;
    if r.status().is_success() {
        let v: Value = r.json().await.map_err(net)?;
        save(&Tokens { access: s(&v, "access_token"), refresh: s(&v, "refresh_token") })?;
        logger::write("INFO", "Twitch verbunden");
        return Ok(PollResult { status: "ok", message: String::new() });
    }
    let v: Value = r.json().await.unwrap_or(json!({}));
    let msg = s(&v, "message");
    let status = match msg.as_str() {
        "authorization_pending" | "slow_down" => "pending",
        "expired_token" | "invalid device code" => "expired",
        _ => return Err(format!("Anmeldung fehlgeschlagen: {msg}")),
    };
    Ok(PollResult { status, message: msg })
}

#[tauri::command]
pub async fn twitch_account(db: State<'_, Db>) -> Result<Value, String> {
    let v = authed(&db, Method::GET, "/users", &[], None).await?;
    let u = &v["data"][0];
    if u.is_null() {
        return Err("Twitch hat keine Kontodaten geliefert.".into());
    }
    Ok(json!({
        "id": s(u, "id"), "login": s(u, "login"), "display_name": s(u, "display_name"),
        "profile_image_url": s(u, "profile_image_url"), "broadcaster_type": s(u, "broadcaster_type"),
    }))
}

#[tauri::command]
pub async fn twitch_channel(db: State<'_, Db>, user_id: String) -> Result<Value, String> {
    let ch = authed(&db, Method::GET, "/channels", &[("broadcaster_id", user_id.as_str())], None).await?;
    let st = authed(&db, Method::GET, "/streams", &[("user_id", user_id.as_str())], None).await?;
    let c = &ch["data"][0];
    let live = &st["data"][0];
    Ok(json!({
        "title": s(c, "title"), "game_id": s(c, "game_id"), "game_name": s(c, "game_name"),
        "tags": c["tags"].clone(),
        "live": !live.is_null(),
        "viewers": live["viewer_count"].as_u64().unwrap_or(0),
        "started_at": s(live, "started_at"),
    }))
}

#[tauri::command]
pub async fn twitch_update(db: State<'_, Db>, user_id: String, title: String, game_id: String, tags: Vec<String>) -> Result<(), String> {
    let title = title.trim().to_string();
    if title.is_empty() || title.chars().count() > 140 {
        return Err("Der Titel muss 1 bis 140 Zeichen lang sein.".into());
    }
    if tags.len() > 10 || tags.iter().any(|t| t.is_empty() || t.chars().count() > 25 || !t.chars().all(|c| c.is_alphanumeric())) {
        return Err("Tags: höchstens 10, je bis 25 Zeichen, nur Buchstaben und Zahlen, keine Leerzeichen.".into());
    }
    let mut body = json!({ "title": title, "tags": tags });
    if !game_id.is_empty() {
        body["game_id"] = json!(game_id);
    }
    authed(&db, Method::PATCH, "/channels", &[("broadcaster_id", user_id.as_str())], Some(body)).await?;
    logger::write("INFO", "Twitch-Kanalinfos aktualisiert");
    Ok(())
}

#[tauri::command]
pub async fn twitch_categories(db: State<'_, Db>, query: String) -> Result<Value, String> {
    let q = query.trim();
    if q.is_empty() {
        return Ok(json!([]));
    }
    let v = authed(&db, Method::GET, "/search/categories", &[("query", q), ("first", "8")], None).await?;
    let list: Vec<Value> = v["data"].as_array().cloned().unwrap_or_default().iter()
        .map(|c| json!({ "id": s(c, "id"), "name": s(c, "name") })).collect();
    Ok(json!(list))
}

#[tauri::command]
pub async fn twitch_logout(db: State<'_, Db>) -> Result<(), String> {
    if let (Some(t), Ok(cid)) = (load(), client_id(&db)) {
        let _ = http().post("https://id.twitch.tv/oauth2/revoke")
            .form(&[("client_id", cid.as_str()), ("token", t.access.as_str())]).send().await;
    }
    forget();
    logger::write("INFO", "Twitch getrennt");
    Ok(())
}

/// Prüft, ob das gespeicherte Token alle aktuell benötigten Berechtigungen besitzt.
#[tauri::command]
pub async fn twitch_scopes_ok(db: State<'_, Db>) -> Result<bool, String> {
    authed(&db, Method::GET, "/users", &[], None).await?; // erneuert das Token bei Bedarf
    let t = load().ok_or_else(|| "Du bist nicht mit Twitch verbunden.".to_string())?;
    let r = http()
        .get("https://id.twitch.tv/oauth2/validate")
        .header("Authorization", format!("OAuth {}", t.access))
        .send()
        .await
        .map_err(net)?;
    if !r.status().is_success() {
        return Ok(false);
    }
    let v: Value = r.json().await.map_err(net)?;
    let have: Vec<&str> = v["scopes"].as_array().map(|a| a.iter().filter_map(|x| x.as_str()).collect()).unwrap_or_default();
    Ok(SCOPES.split_whitespace().all(|sc| have.contains(&sc)))
}

/// Holt den Stream-Key direkt von Twitch. Er wird nie gespeichert, angezeigt oder protokolliert.
pub(crate) async fn stream_key(db: &Db) -> Result<String, String> {
    let u = authed(db, Method::GET, "/users", &[], None).await?;
    let id = s(&u["data"][0], "id");
    let k = authed(db, Method::GET, "/streams/key", &[("broadcaster_id", id.as_str())], None)
        .await
        .map_err(|e| if e.contains("401") || e.contains("403") {
            "Für den Stream-Start fehlt eine Berechtigung. Trenne Twitch in den Einstellungen und verbinde es neu.".to_string()
        } else { e })?;
    let key = s(&k["data"][0], "stream_key");
    if key.is_empty() { Err("Twitch hat keinen Stream-Key geliefert.".into()) } else { Ok(key) }
}
